delete from freeboard;
drop sequence freeboard_idx_seq;
create sequence freeboard_idx_seq;

select * from freeboard order by idx desc;


insert into freeboard (idx, name, password, subject, content, notice, ip) values (freeboard_idx_seq.nextval, 'ȫ�浿' , '1111', '1��', '1���Դϴ�~', 'no', '192.168.0.7');
insert into freeboard (idx, name, password, subject, content, notice, ip) values (freeboard_idx_seq.nextval, '����' , '2222', '2��', '2���Դϴ�~', 'no', '192.168.0.6');
insert into freeboard (idx, name, password, subject, content, notice, ip) values (freeboard_idx_seq.nextval, '�Ӳ���' , '3333', '3��', '3���Դϴ�~', 'no', '192.168.0.5');
insert into freeboard (idx, name, password, subject, content, notice, ip) values (freeboard_idx_seq.nextval, '������' , '4444', '4��', '4���Դϴ�~', 'no', '192.168.0.4');
commit;

update freeboard set hit = 11 where idx = 1;


delete from freeboardcomment;
drop sequence freeboardcomment_idx_seq;
create sequence freeboardcomment_idx_seq;

select * from freeboardcomment order by idx desc;
update freeboardcomment set name='�κ�', content='�츮�� ��������' where idx = 6;
delete from freeboardcomment where idx = 7;