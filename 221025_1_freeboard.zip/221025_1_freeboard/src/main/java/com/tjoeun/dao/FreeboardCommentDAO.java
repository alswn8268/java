package com.tjoeun.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;

import com.tjoeun.vo.FreeboardCommentVO;
import com.tjoeun.vo.FreeboardList;
import com.tjoeun.vo.FreeboardVO;

public class FreeboardCommentDAO {
	
	private static FreeboardCommentDAO instance = new FreeboardCommentDAO();
	private FreeboardCommentDAO() {
		
	}
	public static FreeboardCommentDAO getInstance() {
		return instance;
	}

	// FreeboardCommentService 클래스에서 호출되는 mapper와 수정할 글 정보가 담긴 객체를 넘겨 받고 댓글을 저장하는 freeboardcomment.xml 파일의 insert sql 명령을 실행하는 메소드
	public void insertComment(SqlSession mapper, FreeboardCommentVO co) {
		System.out.println("FreeboardCommentDAO의 insertComment() 메소드 실행");
		// insert, delete, update sql 명령의 실행 결과를 리턴시키면 sql 명령이 성공적으로 실행된 횟수가 리턴된다.
		mapper.insert("insertComment", co);
	}
	
	// FreeboardCommentService 클래스에서 호출되는 mapper와 메인 글의 글 번호를 넘겨 받고 댓글의 개수를 얻어오는 freeboardcomment.xml 파일의 select sql 명령을 실행하는 메소드
	public int commentCount(SqlSession mapper, int idx) {
		System.out.println("FreeboardCommentDAO의 commentCount() 메소드 실행");
		return (int) mapper.selectOne("commentCount", idx);
	}

}
