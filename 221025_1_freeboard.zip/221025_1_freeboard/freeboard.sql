delete from freeboard;
drop sequence freeboard_idx_seq;
create sequence freeboard_idx_seq;

select * from freeboard order by idx desc;

insert into freeboard (idx, name, password, subject, content, notice, ip) values (category_idx_seq.nextval, 'ȫ�浿' , '1111', '1��', '1���Դϴ�~', 'no', '192.168.0.7');
insert into freeboard (idx, name, password, subject, content, notice, ip) values (category_idx_seq.nextval, '����' , '2222', '2��', '2���Դϴ�~', 'no', '192.168.0.6');
insert into freeboard (idx, name, password, subject, content, notice, ip) values (category_idx_seq.nextval, '�Ӳ���' , '3333', '3��', '3���Դϴ�~', 'no', '192.168.0.5');
insert into freeboard (idx, name, password, subject, content, notice, ip) values (category_idx_seq.nextval, '������' , '4444', '4��', '4���Դϴ�~', 'no', '192.168.0.4');
commit;

update freeboard set hit = 11 where idx = 782;