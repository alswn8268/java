delete from fileupload;
drop SEQUENCE fileupload_idx_seq;
CREATE SEQUENCE fileupload_idx_seq;

select * from fileupload;