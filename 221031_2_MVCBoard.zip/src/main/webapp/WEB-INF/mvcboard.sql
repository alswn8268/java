select * from mvcboard order by gup desc, seq asc;

delete from mvcboard;
drop sequence mvcboard_idx_seq;
create sequence mvcboard_idx_seq;

insert into mvcboard (idx, name, subject, content, gup, lev, seq) values (mvcboard_idx_seq.nextval, 'ȫ�浿', '�ȳ��ϼ���', '�ȳ��ϼ���~~~~~~~~~~~~~~~~~~~~~~', mvcboard_idx_seq.currval, 0, 0);
insert into mvcboard (idx, name, subject, content, gup, lev, seq) values (mvcboard_idx_seq.nextval, '�Ӳ���', '�ƴϿ�', '�ƴϿ�...........................', mvcboard_idx_seq.currval, 0, 0);
insert into mvcboard (idx, name, subject, content, gup, lev, seq) values (mvcboard_idx_seq.nextval, '����', '�����մϴ�', '��', mvcboard_idx_seq.currval, 0, 0);
insert into mvcboard (idx, name, subject, content, gup, lev, seq) values (mvcboard_idx_seq.nextval, '������', '��', '��', mvcboard_idx_seq.currval, 0, 0);
commit;

update mvcboard set hit = 0;
