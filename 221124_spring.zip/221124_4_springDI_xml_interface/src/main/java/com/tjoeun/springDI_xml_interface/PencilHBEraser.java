package com.tjoeun.springDI_xml_interface;

public class PencilHBEraser implements Pencil {

	@Override
	public void use() {
		System.out.println("지우개 달린 HB연필 사용");

	}

}
