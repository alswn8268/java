package com.tjoeun.springDI_xml_interface;

public class PencilHB implements Pencil {

	@Override
	public void use() {
		System.out.println("HB연필 사용");

	}

}
