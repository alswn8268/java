package com.tjoeun.springDI_xml_interface;

public interface Pencil {

	public abstract void use();
	
}
