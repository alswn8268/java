insert into article(id, title, content) values (1, '홍길동', '천재');
insert into article(id, title, content) values (2, '임꺽정', '바보');
insert into article(id, title, content) values (3, '장길산', '뭐지');
insert into article(id, title, content) values (4, '일지매', '평범');