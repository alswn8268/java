// 비밀번호가 일치하는지 확인하는 함수
function pwdChk() {
	let userPassword1 = $('#userPassword1').val();
	let userPassword2 = $('#userPassword2').val();
	
	if (userPassword1 != userPassword2) {
		$('#passwordCheckMessage').html('비밀번호가 일치하지 않습니다.');
	} else {
		$('#passwordCheckMessage').html('');
	}
}

// 2에서 추가 - jQuery ajax

// 회원가입을 실행하는 함수
function userRegister(){
	// ajax를 이용해서 index.jsp에서 테이블에 저장할 데이터를 얻어 온다.
	let userID = $('#userID').val();
	let userPassword1 = $('#userPassword1').val();
	let userPassword2 = $('#userPassword2').val();
	let userName = $('#userName').val();
	let userAge = $('#userAge').val();
	let userGender = $('input[name=userGender]:checked').val();
	let userEmail = $('#userEmail').val();

	// jQuery ajax
	$.ajax({
		type: 'POST', // 요청 방식
		url: './UserRegister', // 요청할 서블릿
		data: { // 서블릿으로 전송할 데이터
			// 변수명: 값
			userID: userID,
			userPassword1: userPassword1,
			userPassword2: userPassword2,
			userName: userName,
			userAge: userAge,
			userGender: userGender,
			userEmail, userEmail
		},
		// ajax 요청이 성공하면 정보가 콜백 함수의 인수로 넘어온다.
		success: res => { // ajax 요청이 성공하면 실행할 콜백 함수
			// console.log('요청 성공');
			
			// 다음 데이터 입력을 받기 위해 텍스트 상자의 내용을 지운다.
			$('#userID').val('');
			$('#userPassword1').val('');
			$('#userPassword2').val('');
			$('#userName').val('');
			$('#userAge').val('');
			$('#userEmail').val('');
			
			// 서블릿 응답에 따른 작업을 실행한다.
			switch (res) {
				case '1':
					$('#messageType').html('오류 메시지');
					$('#messageContent').html('모든 내용을 입력하세요.');
					$('#messageCheck').addClass('panel-danger');
					break;
				case '2':
					$('#messageType').html('오류 메시지');
					$('#messageContent').html('비밀번호가 일치하지 않습니다.');		
					$('#messageCheck').addClass('panel-danger');
					break;
				case '3':
					$('#messageType').html('성공 메시지');
					$('#messageContent').html('회원가입에 성공했습니다.');							
					$('#messageCheck').attr('class', 'modal-content panel-primary');
					break;
				case '4':					
					$('#messageType').html('오류 메시지');
					$('#messageContent').html('이미 존재하는 아이디입니다.');							
					$('#messageCheck').addClass('panel-danger');
					break;
			}
			// 회원 가입 상태 모달 창을 띄운다.
			$('#messageModal').modal('show');
		},
		// ajax 요청이 실패하면 에러 정보가 콜백 함수의 인수로 넘어온다.
		error: e => { // ajax 요청이 실패하면 실행할 콜백 함수
			console.log('요청 실패: ', e.status);
		}
	});
}	

function regChk() {
	// ajax를 이용해서 중복 검사할 아이디를 얻어온다.
	let userID = $('#userID').val();
	// console.log(userID);
	
	// jQuery ajax
	$.ajax({
		type: 'POST',
		url: './UserRegisterCheck',
		data: {
			userID: userID
		},
		success: res => {
			switch (res) {
				case '1':
					$('#idCheckMessage').html('아이디를 입력하세요.');
					$('#checkMessage').html('아이디를 입력하세요.');
					$('#idCheck').addClass('panel-danger');
					break;	
				case '2':
					$('#idCheckMessage').html('이미 사용 중인 아이디 입니다.');
					$('#checkMessage').html('이미 사용 중인 아이디 입니다.');
					$('#idCheck').addClass('panel-danger');
					break;	
				case '3':
					$('#idCheckMessage').html('사용 가능한 아이디입니다.');
					$('#checkMessage').html('사용 가능한 아이디입니다.');
					$('#idCheck').addClass('panel-primary');
					break;	
			}
			// 아이디 중복 검사 모달 창을 띄운다.
			$('#idModal').modal('show');			
		},
		error: e =>{
			console.log('요청 실패:', e.status);
		}
	})
}











