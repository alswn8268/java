/*
const job = new Promise((resolve, reject) => {
    setTimeout(() => {
        resolve('job ok!');
    }, 2000);
});

job.then(data => {
    console.log('data: ', data);
});

const job2 = new Promise((resolve, reject) => {
    setTimeout(() => {
        reject('job2 failed!');
    }, 2000);
});

job2.catch(error => {
    console.log('error: ', error);
});
*/

function job() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            reject('job failed!')
        }, 2000);
    });
};

job().catch(error => {
    console.log('error: ', error);
});

function job2() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve('job2 ok!')
        }, 2000);
    });
};

job2().then(data => {
    console.log('data: ', data)
})

job()
    .catch(error2 => {
        console.log('error2: ', error2)
        job2()
            .then(data2 => {
                console.log("data2: ", data2)
            })
    });


job2()
    .then(data3 => {
        console.log("data3: ", data3);
        return job();
    })
    .catch(error3 => {
        console.log("error3: ", error3);
        // Promise에서 오류가 발생했을 때 Promise 객체의 reject() 함수를 실행하면 이어지는 작업을 중지할 수 있다.
        // return Promise.reject(error3);
    })
    .then(data4 => {
        console.log("data4: ", data4);
    })
