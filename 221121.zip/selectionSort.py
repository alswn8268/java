# %% [markdown]
# # selection sort(선택정렬, 교환법) 알고리즘
# 선택 정렬은 i번째 데이터를 선택해서 나머지 데이터(j번째)와 비교하며 정렬한다.
# 정렬할 데이터가 n개일 경우 회전수는 n-1번이 된다.

# %%
list = [8, 3, 4, 9, 1]
n = 5

for i in range(n - 1):
    for j in range(i + 1, n):
        if list[i] > list[j]:
            list[i], list[j] = list[j], list[i]

# %%
def selectionSortAsc(list):
    for i in range(len(list) - 1):
        for j in range(i + 1, len(list)):
            if list[i] > list[j]:
                list[i], list[j] = list[j], list[i]
    return list

# %%
def selectionSortDesc(list):
    for i in range(len(list) - 1):
        for j in range(i + 1, len(list)):
            if list[i] < list[j]:
                list[i], list[j] = list[j], list[i]
    return list

# %%
if __name__ == '__main__':
    list = [8, 3, 4, 9, 1]
    result = selectionSortAsc(list)
    print(result)
    result = selectionSortDesc(list)
    print(result)

# %%



