function hello() {
	alert('얼럿!');
}