// 하이퍼링크를 클릭시 호출했던 fetch 함수의 반복되는 부분을 함수로 구현한다.
function fetchAjax(pageName) {
	fetch(pageName)
		.then(function (res) {
			if (res.status ==  200) {
				res.text().then(function (text) {
					document.querySelectorAll('div')[0].innerHTML=text;
				})
			} else {
					document.querySelectorAll('div')[0].innerHTML='요청 실패';
			}
		});	
}

/*
// javacript onload
onload = function () {
	// 페이지가 로드되거나 새로고침될 때 해시가 없으면 summary 파일에 저장된 내용을 표시하고 해시가 있으면 지정된 파일의 내용을 표시한다.
	// location.hash: 클릭된 하이퍼링크에 붙인 해시를 얻어 온다.
	// console.log('location.hash: ' + location.hash);
	if (location.hash) {
		fetchAjax(location.hash.substring(2));
	} else {
		// console.log('해시 없음');	
		fetchAjax('summary');
	}
}
*/

// jQuery onload
$(() => {
	if (location.hash) {
		fetchAjax(location.hash.substring(2));
	} else {
		fetchAjax('summary');
	}
})