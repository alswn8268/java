package com.tjoeun.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;

import com.tjoeun.springWEB_DBCPTemplate_board.Constant;
import com.tjoeun.vo.MvcboardVO;

public class MvcboardDAO {

	private static final Logger logger = LoggerFactory.getLogger(MvcboardDAO.class);

	// JdbcTemplate 설정
	// DAO 클래스에서 JdbcTemplate를 사용하기 위해서 JdbcTemplate 클래스 타입의 객체를 선언한다.
	private JdbcTemplate template;

	// DAO 클래스의 bean이 기본 생성자로 생성되는 순간 servlet-context.xml 파일에서 생성되어 컨트롤러가 전달받아 Constant 클래스의 JdbcTemplate 클래스 타입의 static 객체에 저장한 bean으로 초기화시킨다.
	public MvcboardDAO() {
		template = Constant.template;
	}
	
// DBCP 방식을 사용하는 개체를 초기화 시키는 부분이므로 DBCP Template으로 코드 변환이 완료되면 주석처리
// ==============================================여기부터=====================================================
//	private DataSource dataSource;
//	
//	public MvcboardDAO() {
//		try {
//			Context context = new InitialContext();
//			dataSource = (DataSource) context.lookup("java:/comp/env/jdbc/oracle");
//			
//			template = Constant.template;
//			
//		} catch (NamingException e) {
//			e.printStackTrace();
//		}
//	}
// ==============================================여기까지=====================================================
	
	// insert, delete, update sql 명령을 실행하는 메소드의 인수로 넘어온 데이터가 중간에 값이 변경되면 안 되기 때문에, JdbcTemplate에서는 insert, delete, update sql 명령을 실행하는 메소드의 인수를 선언할 때
	// 반드시 final을 붙여서 인수로 넘어온 데이터를 수정할 수 없도록 선언해야 한다.
	public void insert(final MvcboardVO mvcboardVO) {
		logger.info("insert()");

		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = dataSource.getConnection();
			String sql = "insert into mvcboard (idx, name, subject, content, gup, lev, seq) values (mvcboard_idx_seq.nextval, ?, ?, ?, mvcboard_idx_seq.currval, 0, 0)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mvcboardVO.getName());
			pstmt.setString(2, mvcboardVO.getSubject());
			pstmt.setString(3, mvcboardVO.getContent());
			pstmt.executeUpdate();		
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		*/
		
		String sql = "insert into mvcboard (idx, name, subject, content, gup, lev, seq) values (mvcboard_idx_seq.nextval, ?, ?, ?, mvcboard_idx_seq.currval, 0, 0)";
		// update(): 테이블의 내용이 갱신되는 sql 명령 => insert, delete, update
		// query(): 테이블의 내용이 갱신되지 않는 sql 명령 => select => 실행 결과가 여러 건인 경우
		// queryForInt(): 테이블의 내용이 갱신되지 않는 sql 명령 => select => 실행 결과가 정수일 경우
		// queryForObject(): 테이블의 내용이 갱신되지 않는 sql 명령 => select => 실행 결과가 1건일 경우

		// update(sql 명령, "?"를 채운다.)
		// update() 메소드의 2번째 인수로 PreparedStatementSetter 인터페이스 객체를 익명으로 구현해서 sql 명령의 "?"를 채운다.
		template.update(sql, new PreparedStatementSetter() {
			// PreparedStatementSetter 인터페이스 객체를 익명으로 구현하면 setValues() 추상 메소드가 자동으로 Override 되고 여기서 "?"를 채운다.
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, mvcboardVO.getName());
				ps.setString(2, mvcboardVO.getSubject());
				ps.setString(3, mvcboardVO.getContent());				
			}
		});
		
	}

	public int selectCount() {
		logger.info("selectCount()");
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		
		try {
			conn = dataSource.getConnection();
			String sql = "select count(*) from mvcboard order by idx desc";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
					
			rs.next();
			result = rs.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return result;
		*/
		String sql = "select count(*) from mvcboard order by idx desc";
		// return template.queryForInt(sql);
		// queryForObject(sql 명령, 리턴타입.class)
		return template.queryForObject(sql, Integer.class);
		
	}

	public ArrayList<MvcboardVO> selectList(HashMap<String, Integer> hmap) {
		logger.info("selectList()");
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		ArrayList<MvcboardVO> list = null;
		
		try {
			conn = dataSource.getConnection();
			String sql = "select * from (" + "select rownum rnum, AA.* from (" + "select * from mvcboard order by gup desc, seq" + ") AA where rownum <= ?" + ") where rnum >= ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, hmap.get("endNo"));
			pstmt.setInt(2, hmap.get("startNo"));
			rs = pstmt.executeQuery();
			
			list = new ArrayList<MvcboardVO>();
			
			while (rs.next()) {
				AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationCTX.xml");
				MvcboardVO mvcboardVO = ctx.getBean("mvcboardVO", MvcboardVO.class);
				mvcboardVO.setIdx(rs.getInt("idx"));
				mvcboardVO.setName(rs.getString("name"));
				mvcboardVO.setSubject(rs.getString("subject"));
				mvcboardVO.setContent(rs.getString("content"));
				mvcboardVO.setGup(rs.getInt("gup"));
				mvcboardVO.setLev(rs.getInt("lev"));
				mvcboardVO.setSeq(rs.getInt("seq"));
				mvcboardVO.setHit(rs.getInt("hit"));
				mvcboardVO.setWriteDate(rs.getTimestamp("writeDate"));
				list.add(mvcboardVO);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
		*/
		
		// JdbcTemplate을 사용하는 경우 select sql 명령에만 "?"를 사용할 수 없다. => "?" 자리에 데이터가 저장된 변수를 직접 사용해야 한다.
		String sql = "select * from (" + "select rownum rnum, AA.* from (" + "select * from mvcboard order by gup desc, seq" + ") AA where rownum <= " + hmap.get("endNo") + ") where rnum >= " + hmap.get("startNo");
		// query(sql 명령, BeanPropertyRowMapper(리턴할 클래스.class))
		// select sql 명령 실행 결과를 BeanPropertyRowMapper 클래스 생성자의 인수로 MvcboardVO 클래스를 넘겨서 sql 명령 실행 결과를 저장시켜 리턴한다.
		// query() 메소드의 실행 결과가 List 인터페이스 타입으로 리턴되기 때문에 메소드의 리턴 타입인 ArrayList<MvcboardVO>로 형변환이 필요하다.
		// 데이터베이스 테이블의 필드 이름과 BeanPropertyRowMapper 클래스의 생성자의 인수로 전달되는 클래스의 필드 이름이 같아야 정상적으로 처리 된다.
		return (ArrayList<MvcboardVO>) template.query(sql, new BeanPropertyRowMapper(MvcboardVO.class)); 
	}
	
	public void increment(final int idx) {
		logger.info("increment()");
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = dataSource.getConnection();
			String sql = "update mvcboard set hit = hit + 1 where idx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			pstmt.executeUpdate();			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		*/
		
		// "?"가 많을 때 사용
//		String sql = "update mvcboard set hit = hit + 1 where idx = ?";
//		template.update(sql, new PreparedStatementSetter() {
//			
//			@Override
//			public void setValues(PreparedStatement ps) throws SQLException {
//				ps.setInt(1, idx);				
//			}
//		});
		 
		// "?"가 많지 않을 때 사용
		String sql = "update mvcboard set hit = hit + 1 where idx = " + idx;
		template.update(sql);
	}

	public MvcboardVO selectByIdx(int idx) {
		logger.info("selectByIdx()");

		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;		
		MvcboardVO mvcboardVO = null;
		
		try {
			conn = dataSource.getConnection();
			String sql = "select * from mvcboard where idx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationCTX.xml");
				mvcboardVO = ctx.getBean("mvcboardVO", MvcboardVO.class);
				
				mvcboardVO.setIdx(rs.getInt("idx"));
				mvcboardVO.setName(rs.getString("name"));
				mvcboardVO.setSubject(rs.getString("subject"));
				mvcboardVO.setContent(rs.getString("content"));
				mvcboardVO.setGup(rs.getInt("gup"));
				mvcboardVO.setLev(rs.getInt("lev"));
				mvcboardVO.setSeq(rs.getInt("seq"));
				mvcboardVO.setHit(rs.getInt("hit"));
				mvcboardVO.setWriteDate(rs.getTimestamp("writeDate"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}		
		return mvcboardVO;
		*/
		String sql = "select * from mvcboard where idx = " + idx;
		return template.queryForObject(sql, new BeanPropertyRowMapper(MvcboardVO.class));
	}

	public void update(final MvcboardVO mvcboardVO) {
		logger.info("update(MvcboardVO mvcboardVO)");
		
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;	
		
		try {
			conn = dataSource.getConnection();		
			String sql = "update mvcboard set subject = ?, content = ? where idx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mvcboardVO.getSubject());
			pstmt.setString(2, mvcboardVO.getContent());
			pstmt.setInt(3, mvcboardVO.getIdx());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		*/
		String sql = "update mvcboard set subject = ?, content = ? where idx = ?";
		template.update(sql, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, mvcboardVO.getSubject());
				ps.setString(2, mvcboardVO.getContent());
				ps.setInt(3, mvcboardVO.getIdx());
			}
		});		
		
	}

	public void update(final int idx, final String subject, final String content) {
		logger.info("update(int idx, String subject, String content)");
	
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = dataSource.getConnection();
			String sql = "update mvcboard set subject = ?, content = ? where idx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, subject);
			pstmt.setString(2, content);
			pstmt.setInt(3, idx);
			pstmt.executeUpdate();			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		*/
//		String sql = "update mvcboard set subject = '"+ subject + "', content = '" + content + "' where idx = ?";
		String sql = String.format("update mvcboard set subject = '%s', content = '%s' where idx = %d", subject, content, idx);
		template.update(sql);
				
	}

	public void delete(final int idx) {
		logger.info("delete()");
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = dataSource.getConnection();
			String sql = "delete from mvcboard where idx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			pstmt.executeUpdate();			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		*/
		String sql = "delete from mvcboard where idx = " + idx;
		template.update(sql);		
		
	}

	public void replyIncrement(final HashMap<String, Integer> hmap) {
		logger.info("replyIncrement()");
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = dataSource.getConnection();
			String sql = "update mvcboard set seq = seq + 1 where gup = ? and seq >= ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, hmap.get("gup"));
			pstmt.setInt(2, hmap.get("seq"));
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		*/
//		String sql = String.format("update mvcboard set seq = seq + 1 where gup = %d and seq >= %d", hmap.get("gup"), hmap.get("seq"));
		String sql = "update mvcboard set seq = seq + 1 where gup = ? and seq >= ?";
		template.update(sql, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setInt(1, hmap.get("gup"));
				ps.setInt(2, hmap.get("seq"));
			}
		});	
		
	}

	public void replyInsert(final MvcboardVO mvcboardVO) {
		logger.info("replyInsert()");
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = dataSource.getConnection();
			String sql = "insert into mvcboard (idx, name, subject, content, gup, lev, seq) values (mvcboard_idx_seq.nextval, ?, ?, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mvcboardVO.getName());
			pstmt.setString(2, mvcboardVO.getSubject());
			pstmt.setString(3, mvcboardVO.getContent());
			pstmt.setInt(4, mvcboardVO.getGup());
			pstmt.setInt(5, mvcboardVO.getLev());
			pstmt.setInt(6, mvcboardVO.getSeq());
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		*/
		String sql = "insert into mvcboard (idx, name, subject, content, gup, lev, seq) values (mvcboard_idx_seq.nextval, ?, ?, ?, ?, ?, ?)";
		template.update(sql, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, mvcboardVO.getName());				
				ps.setString(2, mvcboardVO.getSubject());				
				ps.setString(3, mvcboardVO.getContent());				
				ps.setInt(4, mvcboardVO.getGup());
				ps.setInt(5, mvcboardVO.getLev());
				ps.setInt(6, mvcboardVO.getSeq());
			}
		});	
					
	}
	
}
