package com.tjoeun.springWEB_DBCPTemplate;

import org.springframework.jdbc.core.JdbcTemplate;

public class DAO {

	private JdbcTemplate template;
	public DAO() {
		template = Constant.template;
		System.out.println("연결 성공: " + template);
	}
	
}
