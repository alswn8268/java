select * from register;

delete from register;
commit;