-- article 더미 데이터
insert into article(id, title, content) values (1, '홍길동', '천재');
insert into article(id, title, content) values (2, '임꺽정', '바보');
insert into article(id, title, content) values (3, '장길산', '뭐지');
insert into article(id, title, content) values (4, '일지매', '평범');

insert into article(id, title, content) values (5, '손오공', '좋아하는 드라마는?');
insert into article(id, title, content) values (6, '저팔계', '먹고 싶은 음식은?');
insert into article(id, title, content) values (7, '사오정', '취미는?');


-- comment 더미 데이터
insert into comment(id, nickname, body, article_id) values (1, '한꼬마', '상견니', 5);
insert into comment(id, nickname, body, article_id) values (2, '두꼬마', '주몽', 5);
insert into comment(id, nickname, body, article_id) values (3, '세꼬마', '구그달', 5);

insert into comment(id, nickname, body, article_id) values (4, '한꼬마', '마라탕', 6);
insert into comment(id, nickname, body, article_id) values (5, '두꼬마', '햄버거', 6);
insert into comment(id, nickname, body, article_id) values (6, '세꼬마', '치킨', 6);

insert into comment(id, nickname, body, article_id) values (7, '한꼬마', '독서', 7);
insert into comment(id, nickname, body, article_id) values (8, '두꼬마', '게임', 7);
insert into comment(id, nickname, body, article_id) values (9, '세꼬마', '차 마시기', 7);

