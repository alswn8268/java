package com.tjoeun.firstproject.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

// JPA를 사용해서 테이블과 매핑할 클래스는 @Entity 어노테이션을 필수로 붙이고 엔티티라고 한다.
// @Entity 어노테이션이 붙은 클래스 이름으로 SpringBoot가 자동으로 테이블을 만들고, 클래스 내부에 선언한 필드 이름으로 테이블을 구성하는 컬럼을 만든다.
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
@Entity // Entity로 사용되는 클래스, 기본 생성자가 없으면 에러가 발생한다.
// 메인 글
public class Article {

	// 기본키로 사용할 필드 선언
	// 기본키를 자동으로 생성하려면 @Id와 @GeneratedValue 어노테이션을 함께 사용해야 한다.	
	@Id // 필드를 기본키로 생성한다. // 시퀀스가 1부터 시작한다.
//	@GeneratedValue // 기본키 값을 자동으로 생성한다.
	@GeneratedValue(strategy = GenerationType.IDENTITY) // 시퀀스가 입력된 데이터 개수 다음부터 시작한다.
	private Long id;
	
	@Column // 필드를 테이블 컬럼과 매핑한다.
	private String title;
	
	@Column // 필드를 테이블 컬럼과 매핑한다.
	private String content;

	public void patch(Article article) {
		if (article.title != null) { // 수정할 title이 입력되었는지 확인
			this.title = article.title;
		}
		if (article.content != null) { // 수정할 content가 입력되었는지 확인
			this.content = article.content;
		}
		

	}
	
}


